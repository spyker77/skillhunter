$(document).ready(function () {
    $("#home-form").submit(function () {
        $("#reminder").show();
    });
});